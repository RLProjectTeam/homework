修改内容：
selfplay.py 
alice_history = alice_reward * history